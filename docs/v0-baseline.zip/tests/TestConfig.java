package tests;

/** Public demo credentials, not production secrets. */
final class TestConfig {
    static final String BASE_URL = "https://www.saucedemo.com/";
    static final String VALID_USERNAME = "standard_user";
    static final String VALID_PASSWORD = "secret_sauce";

    private TestConfig() { }
}
