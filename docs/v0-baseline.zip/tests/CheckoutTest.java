package tests;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class CheckoutTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void openBrowser() {
        ChromeOptions options = new ChromeOptions();
        // Prevent Chrome's password dialogs from covering demo-site controls.
        options.setExperimentalOption("prefs", java.util.Map.of(
                "credentials_enable_service", false,
                "profile.password_manager_enabled", false,
                "profile.password_manager_leak_detection", false));
        driver = new ChromeDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new org.openqa.selenium.Dimension(1280, 900));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(TestConfig.BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                driver = null;
            }
        }
    }

    private void login() {
        driver.findElement(By.id("user-name")).sendKeys(TestConfig.VALID_USERNAME);
        driver.findElement(By.id("password")).sendKeys(TestConfig.VALID_PASSWORD);
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
    }

    @Test
    public void customerCanCompleteCheckout() {
        openCheckout();
        driver.findElement(By.id("first-name")).sendKeys("Demo");
        driver.findElement(By.id("last-name")).sendKeys("Customer");
        driver.findElement(By.id("postal-code")).sendKeys("90210");
        driver.findElement(By.id("continue")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-step-two.html"));
        assertEquals(driver.findElement(By.cssSelector(".inventory_item_name")).getText(), "Sauce Labs Backpack");
        driver.findElement(By.id("finish")).click();
        assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='complete-header']"))).getText(), "Thank you for your order!");
        assertTrue(driver.getCurrentUrl().endsWith("/checkout-complete.html"));
    }

    @Test
    public void missingFirstNamePreventsCheckout() {
        openCheckout();
        driver.findElement(By.id("last-name")).sendKeys("Customer");
        driver.findElement(By.id("postal-code")).sendKeys("90210");
        driver.findElement(By.id("continue")).click();
        assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']"))).getText(), "Error: First Name is required");
        assertTrue(driver.getCurrentUrl().endsWith("/checkout-step-one.html"),
                "Invalid checkout must stay on customer information step");
    }

    private void openCheckout() {
        login();
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.cssSelector(".shopping_cart_link")).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("checkout"))).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("first-name")));
    }
}

