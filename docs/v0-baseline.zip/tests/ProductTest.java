package tests;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class ProductTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void openBrowser() {
        ChromeOptions options = new ChromeOptions();
        // Prevent Chrome's password dialogs from covering demo-site controls.
        options.setExperimentalOption("prefs", java.util.Map.of(
                "credentials_enable_service", false,
                "profile.password_manager_enabled", false,
                "profile.password_manager_leak_detection", false));
        driver = new ChromeDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new org.openqa.selenium.Dimension(1280, 900));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(TestConfig.BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                driver = null;
            }
        }
    }

    private void login() {
        driver.findElement(By.id("user-name")).sendKeys(TestConfig.VALID_USERNAME);
        driver.findElement(By.id("password")).sendKeys(TestConfig.VALID_PASSWORD);
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
    }

    @Test
    public void productPageShowsCatalog() {
        login();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".inventory_item")));
        assertEquals(driver.findElement(By.cssSelector("[data-test='title']")).getText(), "Products");
        assertEquals(driver.findElements(By.cssSelector(".inventory_item")).size(), 6,
                "The demo catalog is expected to contain six products");
        assertTrue(driver.findElements(By.cssSelector(".inventory_item_name")).stream()
                .anyMatch(element -> element.getText().equals("Sauce Labs Backpack")),
                "Catalog should contain the backpack");
    }

    @Test
    public void priceSortChangesProductOrder() {
        login();
        var before = driver.findElements(By.cssSelector(".inventory_item_name")).stream()
                .map(element -> element.getText()).toList();
        new org.openqa.selenium.support.ui.Select(
                driver.findElement(By.cssSelector("[data-test='product-sort-container']")))
                .selectByValue("lohi");
        wait.until(d -> "lohi".equals(new org.openqa.selenium.support.ui.Select(
                d.findElement(By.cssSelector("[data-test='product-sort-container']")))
                .getFirstSelectedOption().getAttribute("value")));
        var prices = driver.findElements(By.cssSelector(".inventory_item_price")).stream()
                .map(element -> new java.math.BigDecimal(element.getText().replace("$", ""))).toList();
        assertEquals(prices.size(), 6, "Sorting should preserve all products");
        var expected = new java.util.ArrayList<>(prices);
        expected.sort(java.util.Comparator.naturalOrder());
        assertEquals(prices, expected, "All prices should be in ascending order");
        var after = driver.findElements(By.cssSelector(".inventory_item_name")).stream()
                .map(element -> element.getText()).toList();
        assertNotEquals(after, before, "Price sorting should change the default name order");
    }
}

