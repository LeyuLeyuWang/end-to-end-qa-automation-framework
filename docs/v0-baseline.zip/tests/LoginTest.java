package tests;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class LoginTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void openBrowser() {
        ChromeOptions options = new ChromeOptions();
        // Prevent Chrome's password dialogs from covering demo-site controls.
        options.setExperimentalOption("prefs", java.util.Map.of(
                "credentials_enable_service", false,
                "profile.password_manager_enabled", false,
                "profile.password_manager_leak_detection", false));
        driver = new ChromeDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new org.openqa.selenium.Dimension(1280, 900));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(TestConfig.BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                driver = null;
            }
        }
    }

    @Test
    public void standardUserCanLogin() {
        submitLogin(TestConfig.VALID_USERNAME, TestConfig.VALID_PASSWORD);
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
        assertTrue(driver.getCurrentUrl().endsWith("/inventory.html"), "Login should open inventory");
        assertEquals(driver.findElement(By.cssSelector("[data-test='title']")).getText(), "Products");
    }

    @Test
    public void invalidPasswordIsRejected() {
        submitLogin(TestConfig.VALID_USERNAME, "wrong_password");
        assertLoginError("Epic sadface: Username and password do not match any user in this service");
    }

    @Test
    public void emptyUsernameIsRejected() {
        submitLogin("", TestConfig.VALID_PASSWORD);
        assertLoginError("Epic sadface: Username is required");
    }

    @Test
    public void lockedOutUserIsRejected() {
        submitLogin("locked_out_user", TestConfig.VALID_PASSWORD);
        assertLoginError("Epic sadface: Sorry, this user has been locked out.");
    }

    private void submitLogin(String username, String password) {
        driver.findElement(By.id("user-name")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("login-button")).click();
    }

    private void assertLoginError(String expected) {
        String actual = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']"))).getText();
        assertEquals(actual, expected, "Login error should explain why authentication failed");
        assertTrue(driver.findElement(By.id("login-button")).isDisplayed(),
                "Rejected login should remain on login screen");
        assertFalse(driver.getCurrentUrl().contains("/inventory.html"));
    }
}

