package tests;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class CartTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeMethod
    public void openBrowser() {
        ChromeOptions options = new ChromeOptions();
        // Prevent Chrome's password dialogs from covering demo-site controls.
        options.setExperimentalOption("prefs", java.util.Map.of(
                "credentials_enable_service", false,
                "profile.password_manager_enabled", false,
                "profile.password_manager_leak_detection", false));
        driver = new ChromeDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new org.openqa.selenium.Dimension(1280, 900));
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get(TestConfig.BASE_URL);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")));
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                driver = null;
            }
        }
    }

    private void login() {
        driver.findElement(By.id("user-name")).sendKeys(TestConfig.VALID_USERNAME);
        driver.findElement(By.id("password")).sendKeys(TestConfig.VALID_PASSWORD);
        driver.findElement(By.id("login-button")).click();
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
    }

    @Test
    public void addedProductAppearsInCart() {
        login();
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".shopping_cart_badge"))).getText(), "1");
        driver.findElement(By.cssSelector(".shopping_cart_link")).click();
        wait.until(ExpectedConditions.urlContains("/cart.html"));
        assertEquals(driver.findElements(By.cssSelector(".cart_item")).size(), 1);
        assertEquals(driver.findElement(By.cssSelector(".inventory_item_name")).getText(), "Sauce Labs Backpack");
        assertEquals(driver.findElement(By.cssSelector(".cart_quantity")).getText(), "1");
    }

    @Test
    public void removedProductDisappearsFromCart() {
        login();
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.cssSelector(".shopping_cart_link")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("remove-sauce-labs-backpack"))).click();
        wait.until(ExpectedConditions.numberOfElementsToBe(By.cssSelector(".cart_item"), 0));
        assertEquals(driver.findElements(By.cssSelector(".cart_item")).size(), 0);
        assertEquals(driver.findElements(By.cssSelector(".shopping_cart_badge")).size(), 0,
                "Empty cart should have no count badge");
    }
}

