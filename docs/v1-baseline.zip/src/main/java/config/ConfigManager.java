package config;

import java.time.Duration;

/** System properties override the public demo defaults. */
public final class ConfigManager {
    private ConfigManager() { }

    public static String baseUrl() {
        return System.getProperty("baseUrl", "https://www.saucedemo.com/");
    }

    public static String username() {
        return System.getProperty("username", "standard_user");
    }

    public static String password() {
        return System.getProperty("password", "secret_sauce");
    }

    public static String browser() {
        return System.getProperty("browser", "chrome");
    }

    public static Duration waitTimeout() {
        long seconds = Long.parseLong(System.getProperty("waitSeconds", "10"));
        if (seconds <= 0) {
            throw new IllegalArgumentException("waitSeconds must be positive");
        }
        return Duration.ofSeconds(seconds);
    }
}
