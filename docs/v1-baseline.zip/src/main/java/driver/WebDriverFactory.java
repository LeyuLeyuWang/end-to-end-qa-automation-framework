package driver;

import java.time.Duration;
import java.util.Map;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public final class WebDriverFactory {
    private WebDriverFactory() { }

    public static WebDriver createDriver(String browser) {
        if (!"chrome".equalsIgnoreCase(browser)) {
            throw new IllegalArgumentException("V1 supports Chrome only; requested: " + browser);
        }
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("prefs", Map.of(
                "credentials_enable_service", false,
                "profile.password_manager_enabled", false,
                "profile.password_manager_leak_detection", false));
        WebDriver driver = new ChromeDriver(options);
        try {
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
            driver.manage().window().setSize(new Dimension(1280, 900));
            return driver;
        } catch (RuntimeException failure) {
            try {
                driver.quit();
            } catch (RuntimeException cleanupFailure) {
                failure.addSuppressed(cleanupFailure);
            }
            throw failure;
        }
    }
}
