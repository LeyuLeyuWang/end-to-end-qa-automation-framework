package base;

import config.ConfigManager;
import driver.WebDriverFactory;
import listeners.TestListener;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import pages.LoginPage;
import pages.ProductsPage;

@Listeners(TestListener.class)
public abstract class BaseTest {
    private WebDriver driver;
    protected LoginPage loginPage;

    @BeforeMethod(alwaysRun = true)
    public void openBrowser() {
        driver = WebDriverFactory.createDriver(ConfigManager.browser());
        loginPage = new LoginPage(driver).open();
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser() {
        if (driver != null) {
            try {
                driver.quit();
            } finally {
                driver = null;
                loginPage = null;
            }
        }
    }

    public WebDriver getDriver() { return driver; }

    protected ProductsPage loginAsStandardUser() {
        loginPage.login(ConfigManager.username(), ConfigManager.password());
        return new ProductsPage(driver).awaitLoaded();
    }
}

