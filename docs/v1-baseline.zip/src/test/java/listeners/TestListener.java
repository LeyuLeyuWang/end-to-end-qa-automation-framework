package listeners;

import base.BaseTest;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;
import org.testng.Reporter;
import utils.ScreenshotUtils;

/** Capture immediately after failure, before @AfterMethod quits the browser. */
public final class TestListener implements IInvokedMethodListener {
    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult result) {
        if (result.getStatus() != ITestResult.FAILURE
                || result.getAttribute("screenshot") != null
                || !(result.getInstance() instanceof BaseTest test)
                || test.getDriver() == null) {
            return;
        }
        try {
            String name = result.getTestClass().getRealClass().getSimpleName()
                    + "." + result.getMethod().getMethodName();
            String path = ScreenshotUtils.capture(test.getDriver(), name).toString();
            result.setAttribute("screenshot", path);
            Reporter.log("Failure screenshot: " + path, true);
        } catch (Exception screenshotFailure) {
            // Preserve the original test failure rather than replacing it.
            Reporter.log("Screenshot capture failed: " + screenshotFailure.getMessage(), true);
        }
    }
}

